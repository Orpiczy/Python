# <imię> <nazwisko>, <nr indeksu>

def quicksort() -> None:
    pass


def bubblesort() -> None:
    pass
